// SearchBar.jsx – formularz do filtrowania gier w czasie rzeczywistym

function SearchBar({ searchQuery, onSearchChange, resultCount }) {
  return (
    <div className="searchbar-wrapper">
      <div className="searchbar-container">
        {/* Ikona lupy */}
        <svg
          className="searchbar-icon"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <circle cx="11" cy="11" r="8" />
          <line x1="21" y1="21" x2="16.65" y2="16.65" />
        </svg>

        {/* Pole wyszukiwania – onChange aktualizuje stan w App */}
        <input
          className="searchbar-input"
          type="text"
          placeholder="Szukaj gry po tytule..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          aria-label="Wyszukaj grę"
        />

        {/* Przycisk czyszczenia – widoczny tylko gdy coś wpisano */}
        {searchQuery && (
          <button
            className="searchbar-clear"
            onClick={() => onSearchChange("")}
            aria-label="Wyczyść wyszukiwanie"
          >
            ✕
          </button>
        )}
      </div>

      {/* Licznik wyników wyszukiwania */}
      <p className="searchbar-results">
        {searchQuery
          ? `Znaleziono ${resultCount} gier dla „${searchQuery}"`
          : `${resultCount} gier dostępnych`}
      </p>
    </div>
  );
}

export default SearchBar;
